const assert = require('node:assert').strict;

window.onload = () => {
   
    const allDivs = document.querySelectorAll('div');
    console.log("Todos los divs:");
    allDivs.forEach(div => console.log(div));

    const allButtonsElements = document.querySelectorAll('.buttons');
    console.log("Todos los elementos con clase 'buttons':");
    allButtonsElements.forEach(button => console.log(button));

    const oneButtonDiv = document.querySelector('div.buttons');
    console.log("Un div con clase 'buttons':");
    console.log(oneButtonDiv);

    const allButtonDivs = document.querySelectorAll('div.buttons');
    console.log("Todos los divs con clase 'buttons':");
    allButtonDivs.forEach(div => console.log(div));
};
