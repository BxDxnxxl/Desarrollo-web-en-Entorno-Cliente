window.onload = function(e) {
    console.log('documento cargado')

    function toggleContent(contentId, linkId) {
        const content = document.getElementById(contentId);
        const link = document.getElementById(linkId);
        
        if (content.style.display === 'none' || content.style.display === '') {
            content.style.display = 'block'; 
            link.innerHTML = 'Ocultar contenidos'; 
        } else {
            content.style.display = 'none'; 
            link.innerHTML = 'Mostrar contenidos'; 
        }
    }


    document.getElementById('enlace_1').onclick = function(event) {
        event.preventDefault(); 
        toggleContent('contenidos_1', 'enlace_1');
    };

    document.getElementById('enlace_2').onclick = function(event) {
        event.preventDefault();
        toggleContent('contenidos_2', 'enlace_2');
    };

    document.getElementById('enlace_3').onclick = function(event) {
        event.preventDefault();
        toggleContent('contenidos_3', 'enlace_3');
    };
}
