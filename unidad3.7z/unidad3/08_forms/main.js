window.onload = function() {

    const form = document.getElementById('main_form');
    const submitButton = document.getElementById('submit');
    const opcionesSelect = document.getElementById('opciones');

    
    document.getElementById('pregunta_si').onchange = function() {
        opcionesSelect.disabled = false;
    };
    document.getElementById('pregunta_no').onchange = function() {
        opcionesSelect.disabled = true;
    };
    
    
    document.getElementById('condiciones').onchange = toggleSubmit;
    document.getElementById('privacidad').onchange = toggleSubmit;

    
    form.onsubmit = function(event) {
        event.preventDefault(); 

        if (!form.name.value || !form.surname.value) {
            alert('Por favor, complete los campos de Nombre y Apellidos.');
            return;
        }

        if (form.description.value.length > 80) {
            alert('La descripción no puede tener más de 80 caracteres.');
            return;
        }

        
        console.log('Formulario enviado');
        submitButton.disabled = true; 
        
    };

    function toggleSubmit() {
        submitButton.disabled = !(document.getElementById('condiciones').checked && document.getElementById('privacidad').checked);
    }
}
